$.getJSON("sonar.json", function(json) {
            var hits=json.hits.hits;
            var currentbuildNumber=0;
            var previousbuildNumber=0;
            for(var i=0;i<hits.length;i++)
            {
                if(i==0)
                {
                 currentbuildNumber=parseInt(hits[i]._source["Build Number"]);
                }
                else if(i==1)
                {

                previousbuildNumber=parseInt(hits[i]._source["Build Number"]);
                if(currentbuildNumber<previousbuildNumber)
                {
                    var temp=currentbuildNumber;
                    currentbuildNumber=previousbuildNumber;
                    previousbuildNumber=temp;
                }
                }
            else
            {
                    if(currentbuildNumber<parseInt(hits[i]._source["Build Number"]))
                    {
                        previousbuildNumber=currentbuildNumber;
                        currentbuildNumber=parseInt(hits[i]._source["Build Number"]);
                    }
                    else if (previousbuildNumber<parseInt(hits[i]._source["Build Number"])) {
                        previousbuildNumber= parseInt(hits[i]._source["Build Number"]);
                    }
            }


            }

            var currentObject,previousObject;
            for(var i=0;i<hits.length;i++)
            {
                if(parseInt(hits[i]._source["Build Number"])==currentbuildNumber)
                {
                        currentObject=hits[i]._source;
                }
                else if(parseInt(hits[i]._source["Build Number"])==previousbuildNumber)
                {
                    previousObject=hits[i]._source;
                }
            }




            document.getElementById("buildno").innerHTML=currentObject["Build Number"];
            document.getElementById("runid").innerHTML=currentObject["RunID"];
            document.getElementById("jobname").innerHTML=currentObject["Job Name"];
            document.getElementById("bugs").innerHTML=currentObject["Bugs"];
            document.getElementById("vulnerabilities").innerHTML=currentObject["Vulnerability"];
            document.getElementById("bugsprevious").innerHTML=previousObject["Bugs"];
            document.getElementById("bugscurrent").innerHTML=currentObject["Bugs"];
            document.getElementById("vulnerabilitiesprevious").innerHTML=previousObject["Vulnerability"];
            document.getElementById("vulnerabilitiescurrent").innerHTML=currentObject["Vulnerability"];
             document.getElementById("bugsdeviation").innerHTML= Math.round(((parseInt(currentObject["Bugs"]) - parseInt(previousObject["Bugs"]))/(parseInt(previousObject["Bugs"]) == 0 ? 1 : parseInt(previousObject["Bugs"]))) * 100.00)/100.00;

              document.getElementById("vulnerabilittiesdeviation").innerHTML=Math.round(((parseInt(currentObject["Vulnerability"]) - parseInt(previousObject["Vulnerability"]))/(parseInt(previousObject["Vulnerability"]) == 0 ? 1 : parseInt(previousObject["Vulnerability"]))) * 100.00)/100.00;
               // window.alert(JSON.stringify(currentObject));

                var contentJSON=currentObject.Json;
                var issueArray=contentJSON.issues;
                for(var i=0;i<issueArray.length;i++)
                {

                    var eachIssue=issueArray[i];
                    if(eachIssue.type=="VULNERABILITY")
                    {

                         if(i==0)
                        {
                        var myNode = document.getElementById("dynamicSecurity");
                while (myNode.firstChild) {
                  myNode.removeChild(myNode.firstChild);
                        }
                        }
                     var tablerow=document.createElement('tr');
                   
                
                    var tablecolum1=document.createElement('td');
                    tablecolum1.innerHTML=eachIssue.component;

                            var category=eachIssue.tags;
                    var tablecolum2=document.createElement('td');
                     tablecolum2.innerHTML=category[0];


                      var tablecolum3=document.createElement('td');
                     tablecolum3.innerHTML=eachIssue.severity;

                      var tablecolum4=document.createElement('td');
                     tablecolum4.innerHTML=eachIssue.message;

                     tablerow.appendChild(tablecolum1);
                     tablerow.appendChild(tablecolum2);
                     tablerow.appendChild(tablecolum3);
                     tablerow.appendChild(tablecolum4);
                      document.getElementById("dynamicSecurity").appendChild(tablerow); 
                    }
                     if(eachIssue.type=="BUGS")
                    {
                        if(i==0)
                        {
                        var myNode = document.getElementById("dynamicPerformance");
                while (myNode.firstChild) {
                  myNode.removeChild(myNode.firstChild);
                        }
                        }
                     var tablerow=document.createElement('tr');
                   
                
                    var tablecolum1=document.createElement('td');
                    tablecolum1.innerHTML=eachIssue.component;

                            var category=eachIssue.tags;
                    var tablecolum2=document.createElement('td');
                     tablecolum2.innerHTML=category[0];


                      var tablecolum3=document.createElement('td');
                     tablecolum3.innerHTML=eachIssue.severity;

                      var tablecolum4=document.createElement('td');
                     tablecolum4.innerHTML=eachIssue.message;

                     tablerow.appendChild(tablecolum1);
                     tablerow.appendChild(tablecolum2);
                     tablerow.appendChild(tablecolum3);
                     tablerow.appendChild(tablecolum4);
                      document.getElementById("dynamicSecurity").appendChild(tablerow); 
                    }

                }

            });

/* @author Immanuel Thomas */