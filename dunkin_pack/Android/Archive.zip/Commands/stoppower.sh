#!/bin/sh
/usr/local/bin/adb shell dumpsys batterystats --reset
/usr/local/bin/adb shell dumpsys battery set usb 0
