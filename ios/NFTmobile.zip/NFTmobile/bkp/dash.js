   $.getJSON("sonar.json", function(json) {
             var hits=json.hits.hits;
            var currentbuildNumber=0;
            var previousbuildNumber=0;
            for(var i=0;i<hits.length;i++)
            {
                if(i==0)
                {
                 currentbuildNumber=parseInt(hits[i]._source["Build Number"]);
                }
                else if(i==1)
                {

                previousbuildNumber=parseInt(hits[i]._source["Build Number"]);
                if(currentbuildNumber<previousbuildNumber)
                {
                    var temp=currentbuildNumber;
                    currentbuildNumber=previousbuildNumber;
                    previousbuildNumber=temp;
                }
                }
            else
            {
                    if(currentbuildNumber<parseInt(hits[i]._source["Build Number"]))
                    {
                        previousbuildNumber=currentbuildNumber;
                        currentbuildNumber=parseInt(hits[i]._source["Build Number"]);
                    }
                    else if (previousbuildNumber<parseInt(hits[i]._source["Build Number"])) {
                        previousbuildNumber= parseInt(hits[i]._source["Build Number"]);
                    }
            }
 
               
            }
              var currentObject,previousObject;
            for(var i=0;i<hits.length;i++)
            {
                if(parseInt(hits[i]._source["Build Number"])==currentbuildNumber)
                {
                        currentObject=hits[i]._source;
                }
                else if(parseInt(hits[i]._source["Build Number"])==previousbuildNumber)
                {
                    previousObject=hits[i]._source;
                }
            }

          

            document.getElementById("bugs").innerHTML="Performance Count:"+currentObject["Bugs"];
            document.getElementById("vulnerability").innerHTML="Vulnerability Count:"+currentObject["Vulnerability"];

      });







         $.getJSON("zap.json", function(json) {
       var hits=json.hits.hits;
            var currentbuildNumber=0;
            var previousbuildNumber=0;
            for(var i=0;i<hits.length;i++)
            {
                if(i==0)
                {
                 currentbuildNumber=parseInt(hits[i]._source["Buildno"]);
                }
                else if(i==1)
                {

                previousbuildNumber=parseInt(hits[i]._source["Buildno"]);
                if(currentbuildNumber<previousbuildNumber)
                {
                    var temp=currentbuildNumber;
                    currentbuildNumber=previousbuildNumber;
                    previousbuildNumber=temp;
                }
                }
            else
            {
                    if(currentbuildNumber<parseInt(hits[i]._source["Buildno"]))
                    {
                        previousbuildNumber=currentbuildNumber;
                        currentbuildNumber=parseInt(hits[i]._source["Buildno"]);
                    }
                    else if (previousbuildNumber<parseInt(hits[i]._source["Buildno"])) {
                        previousbuildNumber= parseInt(hits[i]._source["Buildno"]);
                    }
            }
 
               
            }
       
            var currentObject,previousObject;
            for(var i=0;i<hits.length;i++)
            {
                if(parseInt(hits[i]._source["Buildno"])==currentbuildNumber)
                {
                        currentObject=hits[i]._source;
                }
                else if(parseInt(hits[i]._source["Buildno"])==previousbuildNumber)
                {
                    previousObject=hits[i]._source;
                }
            }

             document.getElementById("high").innerHTML="High Issues :"+currentObject["high"];
            document.getElementById("medium").innerHTML="Medium Issues :"+currentObject["med"];
           /* document.getElementById("low").innerHTML="Low :"+currentObject["low"];
            document.getElementById("info").innerHTML="Info :"+currentObject["info"];*/

        });
        

         $.getJSON("access.json", function(json) {
            var hits=json;
            var currentbuildNumber=0;
            var previousbuildNumber=0;
            for(var i=0;i<hits.length;i++)
            {
                if(i==0)
                {
                 currentbuildNumber=parseInt(hits[i]._source["Build Number"]);
                }
                else if(i==1)
                {

                previousbuildNumber=parseInt(hits[i]._source["Build Number"]);
                if(currentbuildNumber<previousbuildNumber)
                {
                    var temp=currentbuildNumber;
                    currentbuildNumber=previousbuildNumber;
                    previousbuildNumber=temp;
                }
                }
            else
            {
                    if(currentbuildNumber<parseInt(hits[i]._source["Build Number"]))
                    {
                        previousbuildNumber=currentbuildNumber;
                        currentbuildNumber=parseInt(hits[i]._source["Build Number"]);
                    }
                    else if (previousbuildNumber<parseInt(hits[i]._source["Build Number"])) {
                        previousbuildNumber= parseInt(hits[i]._source["Build Number"]);
                    }
            }
 
               
            }
 /*           window.alert(previousbuildNumber+":"+currentbuildNumber);*/
            var currentObject,previousObject;
            for(var i=0;i<hits.length;i++)
            {
                if(parseInt(hits[i]._source["Build Number"])==currentbuildNumber)
                {
                        currentObject=hits[i]._source;
                }
                else if(parseInt(hits[i]._source["Build Number"])==previousbuildNumber)
                {
                    previousObject=hits[i]._source;
                }
            }

            document.getElementById("pass").innerHTML="Pass Count:"+currentObject["PassCount"];
            document.getElementById("fail").innerHTML="Fail Count:"+currentObject["FailCount"];
        });



         $.getJSON("load.json", function(json) {
            var hits=json.hits.hits;
            var currentbuildNumber=0;
            var previousbuildNumber=0;
            for(var i=0;i<hits.length;i++)
            {
               
                if(i==0)
                {
                 currentbuildNumber=parseInt(hits[i]._source["BuildNumber"]);
                }
                else if(i==1)
                {

                previousbuildNumber=parseInt(hits[i]._source["BuildNumber"]);
                if(currentbuildNumber<previousbuildNumber)
                {
                    var temp=currentbuildNumber;
                    currentbuildNumber=previousbuildNumber;
                    previousbuildNumber=temp;
                }
                }
            else
            {
                    if(currentbuildNumber<parseInt(hits[i]._source["BuildNumber"]))
                    {
                        previousbuildNumber=currentbuildNumber;
                        currentbuildNumber=parseInt(hits[i]._source["BuildNumber"]);
                    }
                    else if (previousbuildNumber<parseInt(hits[i]._source["BuildNumber"])) {
                        previousbuildNumber= parseInt(hits[i]._source["BuildNumber"]);
                    }
            }
 
               
            }
            
            var currentTransactions=[];
            var previousTransactions=[];
            var currentJob;
            var previousJob;
            /*if(previousbuildNumber==currentbuildNumber)
            {*/
                   for(var i=0;i<hits.length;i++)
                    {   
                           if(parseInt(hits[i]._source["BuildNumber"])==currentbuildNumber)
                                 {
                                        currentJob=hits[i]._source;
                                      currentTransactions.push(hits[i]._source);
                                      previousTransactions.push(hits[i]._source);
                                 } 
                    }
                    previousJob=currentJob;
           /* }*/
            document.getElementById("Violated").innerHTML="SLA Violated:"+currentJob["SLAviolationcount"];
           

        });