$.getJSON("load.json", function(json) {
            var hits=json.hits.hits;
            var currentbuildNumber=0;
            var previousbuildNumber=0;
            for(var i=0;i<hits.length;i++)
            {
              
                if(hits.length==1)
                {
                   
                 currentbuildNumber=parseInt(hits[i]._source["BuildNumber"]);
                 previousbuildNumber=parseInt(hits[i]._source["BuildNumber"]);
                }
                else if(hits.length==2)
                {
                      
                previousbuildNumber=parseInt(hits[i]._source["BuildNumber"]);
                if(currentbuildNumber<previousbuildNumber)
                {
                    var temp=currentbuildNumber;
                    currentbuildNumber=previousbuildNumber;
                    previousbuildNumber=temp;
                }
                }
            else
            {
                
                    if(currentbuildNumber<parseInt(hits[i]._source["BuildNumber"]))
                    {
                       
                        previousbuildNumber=currentbuildNumber;
                        currentbuildNumber=parseInt(hits[i]._source["BuildNumber"]);
                    }
                    else if (previousbuildNumber<parseInt(hits[i]._source["BuildNumber"])&&(parseInt(hits[i]._source["BuildNumber"]))!=currentbuildNumber) {
                        previousbuildNumber= parseInt(hits[i]._source["BuildNumber"]);
                    }
            }
            
             
            }
            //window.alert("testpc"+previousbuildNumber+":"+currentbuildNumber);
            var currentTransactions=[];
            var previousTransactions=[];
            var currentJob;
            var previousJob;
           /* if(previousbuildNumber==currentbuildNumber)
            {*/
                   for(var i=0;i<hits.length;i++)
                    {   
                           if(parseInt(hits[i]._source["BuildNumber"])==currentbuildNumber)
                                 {
                                        currentJob=hits[i]._source;
                                      currentTransactions.push(hits[i]._source);
                                      
                                 } 
                                 else  if(parseInt(hits[i]._source["BuildNumber"])==previousbuildNumber)
                                 {
                                        previousJob=hits[i]._source;
                                      
                                      previousTransactions.push(hits[i]._source);
                                 } 
                    }
               
          /*  }*/
            
                  var percentDetails=[];
            for(var i=0;i<currentTransactions.length;i++)
            {


                for(var j=0;j<previousTransactions.length;j++)
                {

                    if((currentTransactions[i].TransactionName)==(previousTransactions[j].TransactionName))
                    {

                                 var tablerow=document.createElement('tr');
                
                    var tablecolum1=document.createElement('td');
                    var tablecolum2=document.createElement('td');
                    var tablecolum3=document.createElement('td');
                    var tablecolum4=document.createElement('td');


                    tablecolum1.innerHTML=(currentTransactions[i])["TransactionName"];
                    tablecolum2.innerHTML=(previousTransactions[i])["90 Percentile"];
                    tablecolum3.innerHTML=(currentTransactions[i])["90 Percentile"];

                    var currentdev=parseFloat((currentTransactions[i])["90 Percentile"]);
                    var previousdev=parseFloat((previousTransactions[i])["90 Percentile"]);
                   // window.alert(currentdev+":"+previousdev);
                    var updateDeviation=(currentdev-previousdev)/(previousdev);
                    
                   //window.alert(updateDeviation);
                    tablecolum4.innerHTML=updateDeviation==0.0?1:(updateDeviation*100);
                    percentDetails.push(updateDeviation);
                    tablerow.appendChild(tablecolum1);
                    tablerow.appendChild(tablecolum2);
                    tablerow.appendChild(tablecolum3);
                    tablerow.appendChild(tablecolum4);
                

                    
               document.getElementById("percentile90").appendChild(tablerow);   

                    }
                }
                

            }   
                                           
                          
           
            for(var i=0;i<currentTransactions.length;i++)
            {
                 var tablerow=document.createElement('tr');
                
                    var tablecolum1=document.createElement('td');
                    var tablecolum2=document.createElement('td');
                    var tablecolum3=document.createElement('td');
                    var tablecolum4=document.createElement('td');
                    var tablecolum5=document.createElement('td');
                    var tablecolum6=document.createElement('td');
                    var tablecolum7=document.createElement('td');
                    var tablecolum8=document.createElement('td');
                   


                    tablecolum1.innerHTML=(currentTransactions[i])["TransactionName"];
                    tablecolum2.innerHTML=(currentTransactions[i])["Minimum"];
                    tablecolum3.innerHTML=(currentTransactions[i])["Average"];

                    tablecolum4.innerHTML=(currentTransactions[i])["Maximum"];
                    tablecolum5.innerHTML=(currentTransactions[i])["StdDeviation"];
                    tablecolum6.innerHTML=(currentTransactions[i])["90 Percentile"];

                    tablecolum7.innerHTML=(currentTransactions[i])["Pass"];
                    tablecolum8.innerHTML=(currentTransactions[i])["Fail"];
        
                   

                    tablerow.appendChild(tablecolum1);
                    tablerow.appendChild(tablecolum2);
                    tablerow.appendChild(tablecolum3);
                    tablerow.appendChild(tablecolum4);
                    tablerow.appendChild(tablecolum5);
                    tablerow.appendChild(tablecolum6);
                    tablerow.appendChild(tablecolum7);
                    tablerow.appendChild(tablecolum8);
                   
                

                    
               document.getElementById("transactionsummary").appendChild(tablerow);   
           }
                                      

                document.getElementById("runid").innerHTML=currentJob["RunID"];
                document.getElementById("buildno").innerHTML=currentJob["BuildNumber"];
                document.getElementById("userload").innerHTML=currentJob["VirtualUsers"];
                document.getElementById("timings").innerHTML=currentJob["StartTime"]+"-"+currentJob["EndTime"];

                var startdatetimesplit=currentJob["StartTime"].split(' ');
               
                var startdateValues=startdatetimesplit[0].split("/");
             

                var startdates=startdateValues[1]+"/"+startdateValues[0]+"/"+startdateValues[2];
                var startTime=startdates+" "+startdatetimesplit[1];
              
                var enddatetimesplit=currentJob["EndTime"].split(' ');
              
                var enddateValues=enddatetimesplit[1].split("/");
               
                var enddates=enddateValues[1]+"/"+enddateValues[0]+"/"+enddateValues[2];
                var endTime=enddates+" "+enddatetimesplit[2];
              
                var durationMilli=new Date(endTime)-new Date(startTime);
                
                var hours = Math.floor(durationMilli / 3600000); 
                var minutes = Math.floor((durationMilli % 3600000) / 60000); 
                var seconds = Math.floor(((durationMilli % 360000) % 60000) / 1000) ;
                
                document.getElementById("duration").innerHTML=hours+"hr:"+minutes+" mins:"+seconds+" secs";

                document.getElementById("runid").innerHTML=currentJob["RunID"];
                document.getElementById("buildno").innerHTML=currentJob["BuildNumber"];
                document.getElementById("userload").innerHTML=currentJob["VirtualUsers"];
                document.getElementById("timings").innerHTML=currentJob["StartTime"]+"-"+currentJob["EndTime"];

                var vhigh=0,high=0,med=0,low=0;
                for(var i=0;i<percentDetails.length;i++)
                {

                    if(percentDetails[i]>20)
                    {
                        vhigh++
                    }
                    else if(percentDetails[i]>10&&percentDetails[i]<=20)
                    {
                    high++;
                    }
                    else if(percentDetails[i]>=0&&percentDetails[i]<=10)
                    {
                    med++;
                    }
                    else if(percentDetails[i]<0)
                    {
                     low++;
                    }
                }

 document.getElementById("vvhigh").innerHTML=""+vhigh;

 document.getElementById("vhigh").innerHTML=""+high;

 document.getElementById("vmed").innerHTML=""+med;

 document.getElementById("vlow").innerHTML=""+low;


          /* 
             var currentObject,previousObject;
           for(var i=0;i<hits.length;i++)
            {
                if(parseInt(hits[i]._source["Buildno"])==currentbuildNumber)
                {
                        currentObject=hits[i]._source;
                }
                else if(parseInt(hits[i]._source["Buildno"])==previousbuildNumber)
                {
                    previousObject=hits[i]._source;
                }
            }

           */
            


      /*    document.getElementById("buildno").innerHTML=currentObject["Buildno"];
            document.getElementById("runid").innerHTML=currentObject["RunId"];
            
            document.getElementById("high").innerHTML=currentObject["high"];
            document.getElementById("medium").innerHTML=currentObject["med"];
            document.getElementById("low").innerHTML=currentObject["low"];
            document.getElementById("info").innerHTML=currentObject["info"];

            document.getElementById("highprevious").innerHTML=previousObject["high"];
            document.getElementById("highcurrent").innerHTML=currentObject["high"];

            document.getElementById("lowprevious").innerHTML=previousObject["med"];
            document.getElementById("lowcurrent").innerHTML=currentObject["med"];
 


            document.getElementById("mediumprevious").innerHTML=previousObject["low"];
            document.getElementById("mediumcurrent").innerHTML=currentObject["low"];
        

            document.getElementById("infoprevious").innerHTML=previousObject["info"];
            document.getElementById("infocurrent").innerHTML=currentObject["info"];
  */


   
            });


$.getJSON("jmx.json", function(json) {

var hits=json.hits.hits;
            var currentbuildNumber=0;
            var previousbuildNumber=0;
            for(var i=0;i<hits.length;i++)
            {
               
                if(i==0)
                {
                 currentbuildNumber=parseInt(hits[i]._source["Build Number"]);
                }
                else if(i==1)
                {

                previousbuildNumber=parseInt(hits[i]._source["Build Number"]);
                if(currentbuildNumber<previousbuildNumber)
                {
                    var temp=currentbuildNumber;
                    currentbuildNumber=previousbuildNumber;
                    previousbuildNumber=temp;
                }
                }
            else
            {
                    if(currentbuildNumber<parseInt(hits[i]._source["Build Number"]))
                    {
                        previousbuildNumber=currentbuildNumber;
                        currentbuildNumber=parseInt(hits[i]._source["Build Number"]);
                    }
                    else if (previousbuildNumber<parseInt(hits[i]._source["Build Number"])) {
                        previousbuildNumber= parseInt(hits[i]._source["Build Number"]);
                    }
            }
 
               
            }
            /*window.alert(previousbuildNumber+":"+currentbuildNumber);*/


             var currentObject,previousObject;
           for(var i=0;i<hits.length;i++)
            {
                if(parseInt(hits[i]._source["Build Number"])==currentbuildNumber)
                {
                        currentObject=hits[i]._source;
                }
                else if(parseInt(hits[i]._source["Build Number"])==previousbuildNumber)
                {
                    previousObject=hits[i]._source;
                }
            }

            document.getElementById("jmxbuildno").innerHTML=currentObject["Build Number"];
            document.getElementById("jmxrunid").innerHTML=currentObject["Run Id"];
            
            document.getElementById("jmxprojectname").innerHTML=currentObject["Project_name"];

            document.getElementById("jmxcpu").innerHTML=currentObject["CPU"];
            document.getElementById("jmxmemory").innerHTML=currentObject["Memory"];
            
            document.getElementById("jmxthreads").innerHTML=currentObject["ThreadCount"];


            document.getElementById("cpuprevious").innerHTML=previousObject["CPU"];
            document.getElementById("cpucurrent").innerHTML=currentObject["CPU"];

            document.getElementById("memoryprevious").innerHTML=previousObject["Memory"];
            document.getElementById("memorycurrent").innerHTML=currentObject["Memory"];

             document.getElementById("threadprevious").innerHTML=previousObject["ThreadCount"];
            document.getElementById("threadcurrent").innerHTML=currentObject["ThreadCount"];
            var updateCPU=(parseFloat(currentObject["CPU"]) - parseFloat(previousObject["CPU"]))/(parseFloat(previousObject["CPU"])*100);
            var updateMemory=(parseFloat(currentObject["Memory"]) - parseFloat(previousObject["Memory"]))/(parseFloat(previousObject["Memory"])*100);
            var updateThread=(parseFloat(currentObject["ThreadCount"]) - parseFloat(previousObject["ThreadCount"]))/(parseFloat(previousObject["ThreadCount"])*100);
           // window.alert(parseFloat(currentObject["Memory"]) - parseFloat(previousObject["Memory"])/parseFloat(previousObject["Memory"]));
              // Math.round((()) == 0 ? 1 : ((parseFloat(currentObject["Memory"]) - parseFloat(previousObject["Memory"]))/parseFloat(previousObject["Memory"]));
                 document.getElementById("cpudeviation").innerHTML= updateCPU  == 0.0 ? 1 : updateCPU;
                  document.getElementById("memorydeviation").innerHTML= updateMemory  == 0.0 ? 1 : updateMemory;

            
                   document.getElementById("threaddeviation").innerHTML= updateThread  == 0.0 ? 1 : updateThread;
                   
            
            


            

});