  
        $.getJSON("zap.json", function(json) {
            var hits=json.hits.hits;
            var currentbuildNumber=0;
            var previousbuildNumber=0;
            for(var i=0;i<hits.length;i++)
            {
                if(i==0)
                {
                 currentbuildNumber=parseInt(hits[i]._source["Buildno"]);
                }
                else if(i==1)
                {

                previousbuildNumber=parseInt(hits[i]._source["Buildno"]);
                if(currentbuildNumber<previousbuildNumber)
                {
                    var temp=currentbuildNumber;
                    currentbuildNumber=previousbuildNumber;
                    previousbuildNumber=temp;
                }
                }
            else
            {
                    if(currentbuildNumber<parseInt(hits[i]._source["Buildno"]))
                    {
                        previousbuildNumber=currentbuildNumber;
                        currentbuildNumber=parseInt(hits[i]._source["Buildno"]);
                    }
                    else if (previousbuildNumber<parseInt(hits[i]._source["Buildno"])) {
                        previousbuildNumber= parseInt(hits[i]._source["Buildno"]);
                    }
            }
 
               
            }
       
            var currentObject,previousObject;
            for(var i=0;i<hits.length;i++)
            {
                if(parseInt(hits[i]._source["Buildno"])==currentbuildNumber)
                {
                        currentObject=hits[i]._source;
                }
                else if(parseInt(hits[i]._source["Buildno"])==previousbuildNumber)
                {
                    previousObject=hits[i]._source;
                }
            }

           
            


          document.getElementById("buildno").innerHTML=currentObject["Buildno"];
            document.getElementById("runid").innerHTML=currentObject["RunId"];
            
            document.getElementById("high").innerHTML=currentObject["high"];
            document.getElementById("medium").innerHTML=currentObject["med"];
            document.getElementById("low").innerHTML=currentObject["low"];
            document.getElementById("info").innerHTML=currentObject["info"];

            document.getElementById("highprevious").innerHTML=previousObject["high"];
            document.getElementById("highcurrent").innerHTML=currentObject["high"];

            document.getElementById("lowprevious").innerHTML=previousObject["low"];
            document.getElementById("lowcurrent").innerHTML=currentObject["low"];
 


            document.getElementById("mediumprevious").innerHTML=previousObject["med"];
            document.getElementById("mediumcurrent").innerHTML=currentObject["med"];
        

            document.getElementById("infoprevious").innerHTML=previousObject["info"];
            document.getElementById("infocurrent").innerHTML=currentObject["info"];

            document.getElementById("highdeviation").innerHTML=""+ Math.round(((parseInt(currentObject["high"]) - parseInt(previousObject["high"]))/(parseInt(previousObject["high"]) == 0 ? 1 : parseInt(previousObject["high"]))) * 100.00)/100.00;
            document.getElementById("mediumdeviation").innerHTML=""+ Math.round(((parseInt(currentObject["med"]) - parseInt(previousObject["med"]))/(parseInt(previousObject["med"]) == 0 ? 1 : parseInt(previousObject["med"]))) * 100.00)/100.00;
            document.getElementById("lowdeviation").innerHTML=""+ Math.round(((parseInt(currentObject["low"]) - parseInt(previousObject["low"]))/(parseInt(previousObject["low"]) == 0 ? 1 : parseInt(previousObject["low"]))) * 100.00)/100.00;
            document.getElementById("infodeviation").innerHTML=""+ Math.round(((parseInt(currentObject["info"]) - parseInt(previousObject["info"]))/(parseInt(previousObject["info"]) == 0 ? 1 : parseInt(previousObject["info"]))) * 100.00)/100.00;
  





   
            });