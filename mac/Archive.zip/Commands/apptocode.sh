#!/bin/sh
cd $1
java -jar apktool.jar d '$2'
