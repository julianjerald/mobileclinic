#!/bin/sh
/usr/local/bin/adb shell dumpsys batterystats --charged $1 >> $2
