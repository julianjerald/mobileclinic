#!/bin/sh
/usr/local/bin/adb shell wm density
