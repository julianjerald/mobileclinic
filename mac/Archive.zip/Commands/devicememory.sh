#!/bin/sh
/usr/local/bin/adb shell "cat /proc/meminfo | grep "MemTotal""
