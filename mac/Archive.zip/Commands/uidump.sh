#!/bin/sh
adb shell uiautomator dump && adb pull /sdcard/window_dump.xml $1/screen.xml
