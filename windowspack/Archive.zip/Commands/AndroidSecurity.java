import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;


public class AndroidSecurity {
	
	public static void main(String[] args) {
		apktoolfunc();
	  }
	
	
	public static void apktoolfunc() {
		String[] vulnerability_set18 = {"Misuse of App permissions", "Dangerous permissions are enabled in the application manifest. The user must explicitly agree to grant those permissions. These include accessing the camera, contacts, location, microphone, sensors, SMS, and storage.",
				"1. Using APKtool, reverse engineer the apk file.\n" + 
				"2. Observe the permissions in manifest file.\n" + 
				"3. It can be observed that dangerous permissions like WRITE_EXTERNAL_STORAGE\n" + 
				"READ_EXTERNAL_STORAGE\n" + 
				"READ_GSERVICES\n" + 
				"REQUEST_INSTALL_PACKAGES\n" + 
				"READ_PHONE_STATE\n" + 
				"are present in manifest file\n",
				"Medium"				
		};
		String[] vulnerability_set8 = {
				"Missing Code Obfuscation","Reverse engineering is the process of understanding how things work and reusing the information to do something. This is applicable even to Android apps. You might reverse engineer Android apps for Read another’s code, Find vulnerabilities in the code, Search for sensitive data hardcoded in the code, Malware Analysis, Modifying the functionality of an existing application.",
				"1. Converted the .apk file to jar file using dextojar in terminal\n" + 
				"2. Command used\n" + 
				"   sh d2j-dex2jar.sh (path-of apk file)\n" + 
				"3. If permission denied message is displayed, use\n" + 
				"  sudo chmod +x d2j_invoke.sh\n" + 
				"4. try the command in (2) again .apk converts to .jar file\n" + 
				"5. On opening the jar file, the code of the application is visible","Medium"				
		};
		
		String apktool = "/Users/nftcoe/";
		String application = "/Users/nftcoe/downloads/Wyndham-rqa-debug (1).apk";
		
		ProcessBuilder processBuilder = new ProcessBuilder();
		processBuilder.command("/users/nftcoe/documents/script/apptocode.sh",apktool,application);
		try {

			Process process = processBuilder.start();

			StringBuilder output = new StringBuilder();

			BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));

			String line;
			while ((line = reader.readLine()) != null) {
				output.append(line + "\n");
			}

			reader.close();
		}
		catch (IOException e) {
			e.printStackTrace();
		}		
		
		try {

			File fXmlFile = new File("/Users/nftcoe/Amazon/AndroidManifest.xml");
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			
			File file = new File("/Users/nftcoe/Desktop/reportAndroid.json");
			file.createNewFile();
			FileWriter fw = new FileWriter(file);
			BufferedWriter bw = new BufferedWriter(fw);
			JSONArray jsarray = new JSONArray();
			JSONObject jsobject = new JSONObject();
			
			
					
			String[] permissions = {"READ_CALENDAR","WRITE_CALENDAR","CAMERA","READ_CONTACTS\n", "WRITE_CONTACTS\n", "GET_ACCOUNTS", "ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION", "RECORD_AUDIO", "READ_PHONE_STATE", "READ_PHONE_NUMBERS" ,"CALL_PHONE", "ANSWER_PHONE_CALLS", "READ_CALL_LOG", "WRITE_CALL_LOG", "ADD_VOICEMAIL", "USE_SIP", "PROCESS_OUTGOING_CALLS" ,"BODY_SENSORS", "SEND_SMS", "RECEIVE_SMS", "READ_SMS", "RECEIVE_WAP_PUSH", "RECEIVE_MMS", "READ_EXTERNAL_STORAGE", "WRITE_EXTERNAL_STORAGE"};
			
			doc.getDocumentElement().normalize();

			System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
					
			NodeList nList = doc.getElementsByTagName("uses-permission");
					
			System.out.println("----------------------------");

			String comments= "";
			for (int temp = 0; temp < nList.getLength(); temp++) {
				
				

				Node nNode = nList.item(temp);
						
//				System.out.println("\nCurrent Element :" + nNode.getNodeName());
						
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {

					Element eElement = (Element) nNode;
					String permission_name = eElement.getAttribute("android:name");
					
					for (int i = 0; i < permissions.length; i++) {
						if(permission_name.contains(permissions[i])) {
							System.out.println(permission_name);
							comments+=permission_name+"\n ";
						}
					}					
				}
			}	
			jsobject.put("vulnerabilityname",vulnerability_set18[0]);
        	jsobject.put("description",vulnerability_set18[1]);
        	jsobject.put("stepstoreproduce",vulnerability_set18[2]);
        	jsobject.put("comments", comments);
        	jsobject.put("Seviority", vulnerability_set18[3]);
        	jsarray.add(jsobject);
        	bw.write(jsarray.toJSONString());
			
	        bw.close();
        	
		    } catch (Exception e) {
			e.printStackTrace();
		    }
	}

}